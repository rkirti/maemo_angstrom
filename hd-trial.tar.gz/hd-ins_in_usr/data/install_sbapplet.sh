#!/bin/sh -e
# moimart

exit 0;
