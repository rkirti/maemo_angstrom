#define HILDON_BACKGROUND_MANAGER_SERVICE "org.maemo.hildon.background_manager"
#define HILDON_BACKGROUND_MANAGER_OBJECT_PATH "/org/maemo/hildon/background_manager"
#define HILDON_BACKGROUND_MANAGER_INTERFACE "org.maemo.hildon.background_manager"
